class Language {
 final String name;
  final String languageCode;
  Language(this.name, this.languageCode);
}


