String googleMapApiKey = 'YOUR GOOGLE MAP API KEY HERE';
